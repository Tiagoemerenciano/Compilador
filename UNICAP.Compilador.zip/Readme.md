Como executar o projeto

Requisitos:
    - .NET 6 instalado. [https://dotnet.microsoft.com/en-us/download/dotnet/6.0]

Executar na linha de comando:
- dotnet build
- dotnet run [Caminho para o arquivo que será compilado]
- O arquivo de saída com os tokens gerados será salvo na pasta raiz do projeto