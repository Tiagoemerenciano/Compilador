﻿namespace UNICAP.Compilador.Lexical
{
    public class LexicalException : Exception
    {
        public LexicalException(string? message) : base(message) { }
    }
}
